<?php

return [
    'username'      => 'Логин',
    'password'      => 'Пароль',
    'login'         => 'Войти',
    'logout'        => 'Выйти',
    'login_form'    => 'Вход в личный кабинет',
    'personal_area' => 'Личный кабинет',
    'hello'         => 'Добрый день',
    'task2'         => 'Задача №2',
    'task3'         => 'Задача №3',
    'task4'         => 'Задача №4',
    'test_data'     => 'Введите test test или admin admin для теста',
];