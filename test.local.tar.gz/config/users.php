<?php

return [
    'list' => [
        [
            'id'       => 1,
            'username' => 'test',
            'password' => 'test',
            'name'     => 'Тестовый пользователь'
        ],
        [
            'id'       => 2,
            'username' => 'admin',
            'password' => 'admin',
            'name'     => 'Администратор'
        ]
    ]
];